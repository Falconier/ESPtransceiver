"""esp32-sdr-trx: an rtl_tcp receiver and an FM/SSB voice transmitter for one ESP32-S3 board."""
__version__ = "1.0.0-rc4"
